
jQuery.foo = "jQuery FOO here!";
