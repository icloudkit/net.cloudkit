//
// this is a comment
//
define("dimple",
    {
      color: "dimple-blue"
    }
);
