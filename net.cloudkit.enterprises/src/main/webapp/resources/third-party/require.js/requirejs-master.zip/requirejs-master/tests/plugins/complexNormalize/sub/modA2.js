define(['sub/plugin!./modA3'], function(modAName) { return modAName; });
