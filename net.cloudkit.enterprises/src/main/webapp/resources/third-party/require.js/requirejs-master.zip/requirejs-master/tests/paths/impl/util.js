define({
    name: 'impl/util'
});
