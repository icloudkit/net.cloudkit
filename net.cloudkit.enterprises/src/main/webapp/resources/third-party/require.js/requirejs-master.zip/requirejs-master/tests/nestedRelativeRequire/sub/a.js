define(function(require) {
    require(['./b']);
});
