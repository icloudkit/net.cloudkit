define({
    load: function (id, require, load, config) {
        load(id);
    }
});

