define({
    name: 'one'
});
