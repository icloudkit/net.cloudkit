define(["module", "exports", "require"],
            function (module, exports, require) {
    module.exports = "assign2";
});
