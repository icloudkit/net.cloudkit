define('person', [], {
        name: 'person'
});
