console.log('loading thunk...');
script.ready('plugin', function() {
  console.log('bar & baz loaded');
  console.log(thunkor + thunky);
});