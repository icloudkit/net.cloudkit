global.window = {};

require("./colors.js");

module.exports = window.Colors;

