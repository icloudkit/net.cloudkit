describe("growlDirective", function() {
	"use strict";

	it("should be true ", function() {
		expect(true).toBe(true);
	});
});