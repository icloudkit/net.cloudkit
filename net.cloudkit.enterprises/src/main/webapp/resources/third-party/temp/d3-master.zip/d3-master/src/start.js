!function(){
  var d3 = {version: "3.4.8"}; // semver
