define('define-g', [], function(require, exports) {
  exports.name = 'g'
}, { name: 'error' });
