define({ name: 'a' })
