define(function(require, exports) {
  exports.name = 't4'
});
