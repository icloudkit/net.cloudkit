define(function(require){
  var d = require('./d1')
  return d
})