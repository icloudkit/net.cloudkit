define(function(require, exports) {

  exports.name = 'a'
  exports.count = 0

})

