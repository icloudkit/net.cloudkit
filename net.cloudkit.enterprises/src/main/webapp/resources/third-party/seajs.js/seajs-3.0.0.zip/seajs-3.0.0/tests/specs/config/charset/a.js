define(function(require, exports) {

  exports.message = '��� GBK'

});
