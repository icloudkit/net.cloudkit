define(function() {
  //non return
});