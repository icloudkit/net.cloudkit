package com.cloudkit.example

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class CloudkitExampleApplication {

	static void main(String[] args) {
		SpringApplication.run CloudkitExampleApplication, args
	}
}
