<style>
.name{
    color:#ff0;
}
</style>

<template>
<div>
    <div class="name">{{name}}</div>
</div>
</template>

<script>
export default {
    data() {
        return {
        	 name:"VueJS"
        }
    }
} 
</script>

