本实例包含vue-router和vue-resource插件。 如有疑问可以进QQ群：240319632探讨！

###npm install
###npm run dev
###npm run build
