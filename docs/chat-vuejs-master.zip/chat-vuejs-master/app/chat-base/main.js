import app from './components-base/app';

Vue.config.debug = true;

new Vue(app);