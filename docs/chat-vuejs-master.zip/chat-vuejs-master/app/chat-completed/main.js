import app from './components-all/app';

Vue.config.debug = true;

new Vue(app);